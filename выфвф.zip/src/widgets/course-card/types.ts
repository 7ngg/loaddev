export interface Course {
  title: string
  image: string
  description: string
  price: number
  isCompleted: boolean
}
