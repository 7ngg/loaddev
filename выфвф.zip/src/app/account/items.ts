import { SidebarItem } from "@/widgets/sidebar";

export const sidebarItems: SidebarItem[] = [
  {
    title: "Account Settings",
    href: "",
  },
  {
    title: "Enrolled courses",
    href: "",
  },
  {
    title: "Sidebar item 1",
    href: "",
  },
  {
    title: "Sidebar item 2",
    href: "",
  },
  {
    title: "Sidebar item 3",
    href: "",
  },
];
