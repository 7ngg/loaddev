# Load.dev

Final project on Next.js course at ITStep inspired by boot.dev
