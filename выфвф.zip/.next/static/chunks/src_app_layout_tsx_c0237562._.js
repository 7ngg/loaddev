(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__c3c7a40a._.css",
  "static/chunks/node_modules_3741d937._.js",
  "static/chunks/src_07fb38b1._.js"
],
    source: "dynamic"
});
