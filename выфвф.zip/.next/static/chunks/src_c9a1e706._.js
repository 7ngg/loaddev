(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/store/courseStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useCourseStore": (()=>useCourseStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
// Безопасное выполнение JavaScript кода
const safeEval = (code, validationFunction)=>{
    try {
        const fn = new Function(`
      ${code}
      return (${validationFunction})();
    `);
        return fn();
    } catch (error) {
        return false;
    }
};
// Проверка JavaScript кода
const validateJavaScript = (code, testCases)=>{
    return testCases.map((test)=>{
        try {
            const result = safeEval(code, test.validationFunction);
            return String(result) === test.expectedBehavior;
        } catch  {
            return false;
        }
    });
};
// Проверка Python кода (в реальном приложении здесь будет отправка на Python-сервер)
const validatePython = (code, testCases)=>{
    // Здесь будет реальная проверка Python кода
    return testCases.map((test)=>{
        try {
            // В реальном приложении здесь будет отправка кода на Python-сервер
            // и получение результата выполнения
            return false;
        } catch  {
            return false;
        }
    });
};
// Проверка TypeScript кода
const validateTypeScript = (code, testCases)=>{
    // В реальном приложении здесь будет компиляция TypeScript
    return testCases.map((test)=>{
        try {
            const result = safeEval(code, test.validationFunction);
            return String(result) === test.expectedBehavior;
        } catch  {
            return false;
        }
    });
};
// Проверка Java кода
const validateJava = (code, testCases)=>{
    // В реальном приложении здесь будет компиляция и выполнение Java кода
    return testCases.map((test)=>{
        try {
            // В реальном приложении здесь будет отправка кода на Java-сервер
            // и получение результата выполнения
            return false;
        } catch  {
            return false;
        }
    });
};
const useCourseStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        courses: {
            "javascript-basics": {
                id: "javascript-basics",
                title: "JavaScript Fundamentals",
                description: "Master the basics of JavaScript programming",
                level: "Beginner",
                duration: "4 weeks",
                lessons: 24,
                exercises: 12,
                language: "javascript",
                lessonsList: [
                    {
                        id: "calculator",
                        title: "Simple Calculator",
                        description: "Create a calculator that can perform basic arithmetic operations",
                        task: `Create a calculator function that:
1. Takes two numbers and an operation as parameters
2. Supports addition, subtraction, multiplication, and division
3. Returns the result of the operation
4. Handles division by zero
5. Returns null for invalid operations`,
                        initialCode: `function calculator(a, b, operation) {
  // Your code here
  // Example:
  // calculator(5, 3, '+') should return 8
  // calculator(5, 3, '-') should return 2
  // calculator(5, 3, '*') should return 15
  // calculator(6, 3, '/') should return 2
  // calculator(5, 0, '/') should return null
  // calculator(5, 3, 'invalid') should return null
}`,
                        testCases: [
                            {
                                input: "calculator(5, 3, '+')",
                                expectedBehavior: "Should return 8",
                                description: "Addition test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '+');
                return typeof result === 'number' && result === 8;
              }`
                            },
                            {
                                input: "calculator(5, 3, '-')",
                                expectedBehavior: "Should return 2",
                                description: "Subtraction test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '-');
                return typeof result === 'number' && result === 2;
              }`
                            },
                            {
                                input: "calculator(5, 3, '*')",
                                expectedBehavior: "Should return 15",
                                description: "Multiplication test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '*');
                return typeof result === 'number' && result === 15;
              }`
                            },
                            {
                                input: "calculator(6, 3, '/')",
                                expectedBehavior: "Should return 2",
                                description: "Division test",
                                validationFunction: `() => {
                const result = calculator(6, 3, '/');
                return typeof result === 'number' && result === 2;
              }`
                            },
                            {
                                input: "calculator(5, 0, '/')",
                                expectedBehavior: "Should return null for division by zero",
                                description: "Division by zero test",
                                validationFunction: `() => {
                const result = calculator(5, 0, '/');
                return result === null;
              }`
                            },
                            {
                                input: "calculator(5, 3, 'invalid')",
                                expectedBehavior: "Should return null for invalid operation",
                                description: "Invalid operation test",
                                validationFunction: `() => {
                const result = calculator(5, 3, 'invalid');
                return result === null;
              }`
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "array-manipulation",
                        title: "Array Manipulation",
                        description: "Create functions to manipulate arrays",
                        task: `Create a function that:
1. Takes an array of numbers
2. Removes all duplicates
3. Sorts the array in ascending order
4. Returns the sum of all numbers
5. Handles empty arrays and invalid input`,
                        initialCode: `function processArray(arr) {
  // Your code here
  // Example:
  // processArray([1, 2, 2, 3, 3, 4]) should return 10
  // processArray([]) should return 0
  // processArray(null) should return 0
}`,
                        testCases: [
                            {
                                input: "processArray([1, 2, 2, 3, 3, 4])",
                                expectedBehavior: "Should return sum of unique sorted numbers",
                                description: "Basic array processing test",
                                validationFunction: `() => {
                const result = processArray([1, 2, 2, 3, 3, 4]);
                return typeof result === 'number' && result === 10;
              }`
                            },
                            {
                                input: "processArray([])",
                                expectedBehavior: "Should return 0 for empty array",
                                description: "Empty array test",
                                validationFunction: `() => {
                const result = processArray([]);
                return result === 0;
              }`
                            },
                            {
                                input: "processArray(null)",
                                expectedBehavior: "Should return 0 for invalid input",
                                description: "Invalid input test",
                                validationFunction: `() => {
                const result = processArray(null);
                return result === 0;
              }`
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "string-manipulation",
                        title: "String Manipulation",
                        description: "Create functions to manipulate strings",
                        task: `Create a function that:
1. Takes a string as input
2. Reverses the string
3. Removes all spaces
4. Converts to lowercase
5. Returns the result
6. Handles empty strings and invalid input`,
                        initialCode: `function processString(str) {
  // Your code here
  // Example:
  // processString("Hello World") should return "dlrowolleh"
  // processString("") should return ""
  // processString(null) should return ""
}`,
                        testCases: [
                            {
                                input: 'processString("Hello World")',
                                expectedBehavior: "Should return reversed string without spaces",
                                description: "Basic string processing test",
                                validationFunction: `() => {
                const result = processString("Hello World");
                return result === "dlrowolleh";
              }`
                            },
                            {
                                input: 'processString("")',
                                expectedBehavior: "Should return empty string",
                                description: "Empty string test",
                                validationFunction: `() => {
                const result = processString("");
                return result === "";
              }`
                            },
                            {
                                input: "processString(null)",
                                expectedBehavior: "Should return empty string for invalid input",
                                description: "Invalid input test",
                                validationFunction: `() => {
                const result = processString(null);
                return result === "";
              }`
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "python-basics": {
                id: "python-basics",
                title: "Python Programming",
                description: "Learn Python from scratch with practical examples",
                level: "Beginner",
                duration: "6 weeks",
                lessons: 30,
                exercises: 15,
                language: "python",
                lessonsList: [
                    {
                        id: "python-variables",
                        title: "Python Variables and Data Types",
                        description: "Learn about Python variables and basic data types",
                        task: "Create variables of different types and a function that returns their types",
                        initialCode: "# Create variables of different types\nnumber = 42\nstring = 'Hello'\nboolean = True\nmy_list = [1, 2, 3]\nmy_dict = {'name': 'John'}\n\n# Create a function that returns the types of these variables\ndef get_types():\n    # Your code here\n    return [\n        type(number),\n        type(string),\n        type(boolean),\n        type(my_list),\n        type(my_dict)\n    ]\n",
                        testCases: [
                            {
                                input: "str(get_types()[0])",
                                expectedBehavior: "<class 'int'>",
                                description: "Integer type check"
                            },
                            {
                                input: "str(get_types()[1])",
                                expectedBehavior: "<class 'str'>",
                                description: "String type check"
                            },
                            {
                                input: "str(get_types()[2])",
                                expectedBehavior: "<class 'bool'>",
                                description: "Boolean type check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "python-functions",
                        title: "Python Functions",
                        description: "Learn about Python function definitions and scope",
                        task: "Create a function that demonstrates different scopes and returns the correct values",
                        initialCode: "# Create a function that demonstrates different scopes\ndef demonstrate_scope():\n    global_var = 'I am global'\n    \n    def inner():\n        local_var = 'I am local'\n        return [global_var, local_var]\n    \n    # Your code here\n    return inner()\n",
                        testCases: [
                            {
                                input: "demonstrate_scope()[0]",
                                expectedBehavior: "I am global",
                                description: "Global scope access check"
                            },
                            {
                                input: "demonstrate_scope()[1]",
                                expectedBehavior: "I am local",
                                description: "Local scope access check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "python-lists",
                        title: "Python Lists and List Comprehension",
                        description: "Learn about Python list operations and list comprehension",
                        task: "Create a function that uses list comprehension to transform data",
                        initialCode: "# Create a function that uses list comprehension\ndef transform_list(numbers):\n    # Your code here\n    # 1. Filter out even numbers\n    # 2. Square the remaining numbers\n    # 3. Return the sum\n    return sum([x**2 for x in numbers if x % 2 != 0])\n",
                        testCases: [
                            {
                                input: "transform_list([1, 2, 3, 4, 5])",
                                expectedBehavior: "35",
                                description: "List transformation check"
                            },
                            {
                                input: "transform_list([2, 4, 6, 8])",
                                expectedBehavior: "0",
                                description: "Empty result check"
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "typescript-advanced": {
                id: "typescript-advanced",
                title: "TypeScript Mastery",
                description: "Advanced TypeScript patterns and best practices",
                level: "Advanced",
                duration: "8 weeks",
                lessons: 32,
                exercises: 18,
                language: "typescript",
                lessonsList: [
                    {
                        id: "typescript-generics",
                        title: "TypeScript Generics",
                        description: "Learn about TypeScript generics and type constraints",
                        task: "Create a generic function that works with different types",
                        initialCode: "// Create a generic function\nfunction processData<T>(data: T): T {\n  // Your code here\n  return data;\n}\n\n// Create a generic class\nclass Container<T> {\n  private value: T;\n\n  constructor(value: T) {\n    this.value = value;\n  }\n\n  getValue(): T {\n    return this.value;\n  }\n}\n",
                        testCases: [
                            {
                                input: "processData<number>(42)",
                                expectedBehavior: "42",
                                description: "Generic function with number"
                            },
                            {
                                input: "new Container<string>('test').getValue()",
                                expectedBehavior: "test",
                                description: "Generic class with string"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "typescript-interfaces",
                        title: "TypeScript Interfaces",
                        description: "Learn about TypeScript interfaces and type definitions",
                        task: "Create an interface and implement it in a class",
                        initialCode: "// Create an interface\ninterface User {\n  id: number;\n  name: string;\n  email: string;\n}\n\n// Create a class that implements the interface\nclass UserImpl implements User {\n  // Your code here\n  constructor(\n    public id: number,\n    public name: string,\n    public email: string\n  ) {}\n}\n",
                        testCases: [
                            {
                                input: "new UserImpl(1, 'John', 'john@example.com').name",
                                expectedBehavior: "John",
                                description: "Interface implementation check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "typescript-advanced-types",
                        title: "Advanced TypeScript Types",
                        description: "Learn about advanced TypeScript type features",
                        task: "Create utility types and type guards",
                        initialCode: "// Create utility types\ntype Nullable<T> = T | null;\ntype ReadOnly<T> = { readonly [P in keyof T]: T[P] };\n\n// Create a type guard\nfunction isString(value: unknown): value is string {\n  return typeof value === 'string';\n}\n\n// Create a function that uses these types\nfunction processValue<T>(value: Nullable<T>): string {\n  if (value === null) return 'null';\n  if (isString(value)) return value.toUpperCase();\n  return String(value);\n}\n",
                        testCases: [
                            {
                                input: "processValue('hello')",
                                expectedBehavior: "HELLO",
                                description: "Type guard check"
                            },
                            {
                                input: "processValue(null)",
                                expectedBehavior: "null",
                                description: "Nullable type check"
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "java-basics": {
                id: "java-basics",
                title: "Java Programming",
                description: "Learn Java programming fundamentals",
                level: "Intermediate",
                duration: "8 weeks",
                lessons: 36,
                exercises: 20,
                language: "java",
                lessonsList: [
                    {
                        id: "java-classes",
                        title: "Java Classes and Objects",
                        description: "Learn about Java classes and object-oriented programming",
                        task: "Create a class with properties and methods",
                        initialCode: "public class Person {\n    private String name;\n    private int age;\n\n    // Create constructor\n    public Person(String name, int age) {\n        this.name = name;\n        this.age = age;\n    }\n\n    // Create getters and setters\n    public String getName() {\n        return name;\n    }\n\n    public void setName(String name) {\n        this.name = name;\n    }\n\n    public int getAge() {\n        return age;\n    }\n\n    public void setAge(int age) {\n        this.age = age;\n    }\n\n    // Create a method that returns a string representation\n    public String toString() {\n        return name + \" is \" + age + \" years old\";\n    }\n}\n",
                        testCases: [
                            {
                                input: "new Person(\"John\", 25).toString()",
                                expectedBehavior: "John is 25 years old",
                                description: "Class implementation check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "java-interfaces",
                        title: "Java Interfaces",
                        description: "Learn about Java interfaces and their implementation",
                        task: "Create an interface and implement it in a class",
                        initialCode: "interface Drawable {\n    void draw();\n    String getColor();\n}\n\nclass Circle implements Drawable {\n    private String color;\n    private double radius;\n\n    public Circle(String color, double radius) {\n        this.color = color;\n        this.radius = radius;\n    }\n\n    @Override\n    public void draw() {\n        // Implementation would go here\n    }\n\n    @Override\n    public String getColor() {\n        return color;\n    }\n\n    public double getArea() {\n        return Math.PI * radius * radius;\n    }\n}\n",
                        testCases: [
                            {
                                input: "new Circle(\"red\", 5.0).getColor()",
                                expectedBehavior: "red",
                                description: "Interface implementation check"
                            },
                            {
                                input: "String.format(\"%.2f\", new Circle(\"blue\", 3.0).getArea())",
                                expectedBehavior: "28.27",
                                description: "Class method check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "java-collections",
                        title: "Java Collections",
                        description: "Learn about Java collections framework",
                        task: "Create a class that uses different collection types",
                        initialCode: "import java.util.*;\n\nclass CollectionManager {\n    private List<String> names;\n    private Set<Integer> numbers;\n    private Map<String, Integer> scores;\n\n    public CollectionManager() {\n        names = new ArrayList<>();\n        numbers = new HashSet<>();\n        scores = new HashMap<>();\n    }\n\n    public void addName(String name) {\n        names.add(name);\n    }\n\n    public void addNumber(int number) {\n        numbers.add(number);\n    }\n\n    public void addScore(String name, int score) {\n        scores.put(name, score);\n    }\n\n    public List<String> getNames() {\n        return names;\n    }\n\n    public Set<Integer> getNumbers() {\n        return numbers;\n    }\n\n    public Map<String, Integer> getScores() {\n        return scores;\n    }\n}\n",
                        testCases: [
                            {
                                input: "new CollectionManager().getNames().size()",
                                expectedBehavior: "0",
                                description: "Empty collection check"
                            }
                        ],
                        completed: false
                    }
                ]
            }
        },
        currentLessonIndex: 0,
        code: "",
        isRunning: false,
        testResults: [],
        setCurrentLessonIndex: (index)=>set({
                currentLessonIndex: index
            }),
        setCode: (code)=>set({
                code
            }),
        setIsRunning: (isRunning)=>set({
                isRunning
            }),
        setTestResults: (results)=>set({
                testResults: results
            }),
        resetCode: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const lesson = courses[courseId].lessonsList[currentLessonIndex];
            set({
                code: lesson.initialCode,
                testResults: []
            });
        },
        runCode: ()=>{
            const { courses, currentLessonIndex, code } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            const lesson = course.lessonsList[currentLessonIndex];
            set({
                isRunning: true
            });
            // Выполняем проверку кода в зависимости от языка
            setTimeout(()=>{
                let results = [];
                switch(course.language.toLowerCase()){
                    case "javascript":
                        results = validateJavaScript(code, lesson.testCases);
                        break;
                    case "python":
                        results = validatePython(code, lesson.testCases);
                        break;
                    case "typescript":
                        results = validateTypeScript(code, lesson.testCases);
                        break;
                    case "java":
                        results = validateJava(code, lesson.testCases);
                        break;
                    default:
                        results = lesson.testCases.map(()=>false);
                }
                set({
                    testResults: results,
                    isRunning: false
                });
                // Если все тесты пройдены, отмечаем урок как завершенный
                if (results.every((result)=>result)) {
                    const updatedCourses = {
                        ...courses
                    };
                    updatedCourses[courseId].lessonsList[currentLessonIndex].completed = true;
                    set({
                        courses: updatedCourses
                    });
                }
            }, 1000);
        },
        nextLesson: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            if (currentLessonIndex < course.lessonsList.length - 1) {
                const nextIndex = currentLessonIndex + 1;
                set({
                    currentLessonIndex: nextIndex,
                    code: course.lessonsList[nextIndex].initialCode,
                    testResults: []
                });
            }
        },
        previousLesson: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            if (currentLessonIndex > 0) {
                const prevIndex = currentLessonIndex - 1;
                set({
                    currentLessonIndex: prevIndex,
                    code: course.lessonsList[prevIndex].initialCode,
                    testResults: []
                });
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/courses/[id]/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CoursePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/react-fontawesome/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-solid-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/courseStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$monaco$2d$editor$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@monaco-editor/react/dist/index.mjs [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$monaco$2d$editor$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@monaco-editor/react/dist/index.mjs [app-client] (ecmascript) <locals>");
;
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
// Динамически импортируем Monaco Editor для уменьшения размера бандла
const MonacoEditor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_c = ()=>__turbopack_context__.r("[project]/node_modules/@monaco-editor/react/dist/index.mjs [app-client] (ecmascript, next/dynamic entry, async loader)")(__turbopack_context__.i), {
    loadableGenerated: {
        modules: [
            "[project]/node_modules/@monaco-editor/react/dist/index.mjs [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-[400px] bg-[var(--background-darker)] animate-pulse"
        }, void 0, false, {
            fileName: "[project]/src/app/courses/[id]/page.tsx",
            lineNumber: 31,
            columnNumber: 18
        }, this)
});
_c1 = MonacoEditor;
// В реальном приложении эти данные будут приходить с сервера
const courses = {
    "javascript-basics": {
        id: "javascript-basics",
        title: "JavaScript Fundamentals",
        description: "Master the basics of JavaScript programming",
        level: "Beginner",
        duration: "4 weeks",
        lessons: 24,
        exercises: 12,
        language: "javascript",
        lessonsList: [
            {
                id: "variables",
                title: "Variables and Data Types",
                description: "Learn about JavaScript variables and different data types",
                task: "Create variables of different types and use them in a function",
                initialCode: "// Create variables of different types\nconst number = 42;\nconst string = 'Hello';\nconst boolean = true;\nconst array = [1, 2, 3];\nconst object = { name: 'John' };\n\n// Create a function that uses these variables\nfunction useVariables() {\n  // Your code here\n}\n",
                testCases: [
                    {
                        input: "typeof number",
                        expected: "number"
                    },
                    {
                        input: "typeof string",
                        expected: "string"
                    },
                    {
                        input: "typeof boolean",
                        expected: "boolean"
                    }
                ],
                completed: false
            },
            {
                id: "functions",
                title: "Functions and Scope",
                description: "Learn about function declarations and scope in JavaScript",
                task: "Create a function that demonstrates different scopes",
                initialCode: "// Create a function with different scopes\nfunction demonstrateScope() {\n  // Your code here\n}\n",
                testCases: [
                    {
                        input: "typeof demonstrateScope",
                        expected: "function"
                    }
                ],
                completed: false
            }
        ]
    },
    "typescript-advanced": {
        id: "typescript-advanced",
        title: "TypeScript Mastery",
        description: "Advanced TypeScript patterns and best practices",
        level: "Advanced",
        duration: "6 weeks",
        lessons: 32,
        exercises: 18,
        language: "typescript",
        lessonsList: [
            {
                id: "generics",
                title: "Generic Types",
                description: "Learn about TypeScript generics and type constraints",
                task: "Create a generic function that works with different types",
                initialCode: "// Create a generic function\nfunction processData<T>(data: T): T {\n  // Your code here\n  return data;\n}\n",
                testCases: [
                    {
                        input: "processData<number>(42)",
                        expected: "42"
                    }
                ],
                completed: false
            }
        ]
    },
    "nodejs-backend": {
        id: "nodejs-backend",
        title: "Node.js Backend Development",
        description: "Build scalable backend applications with Node.js",
        level: "Intermediate",
        duration: "8 weeks",
        lessons: 40,
        exercises: 24,
        language: "javascript",
        lessonsList: [
            {
                id: "express-routes",
                title: "Express.js Routes",
                description: "Learn how to create and manage routes in Express.js",
                task: "Create a basic Express.js server with multiple routes",
                initialCode: "// Write your Express.js server code here\n",
                testCases: [
                    {
                        input: "app.get",
                        expected: "function"
                    }
                ],
                completed: false
            }
        ]
    }
};
function CoursePage() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { courses, currentLessonIndex, code, isRunning, testResults, setCurrentLessonIndex, setCode, setIsRunning, setTestResults, resetCode, runCode, nextLesson, previousLesson } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCourseStore"])();
    const course = courses[params.id];
    if (!course) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex items-center justify-center bg-gradient-to-br from-[var(--background)] to-[var(--background-darker)]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
                initial: {
                    opacity: 0,
                    y: 20
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                className: "text-2xl text-gray-400",
                children: "Course not found"
            }, void 0, false, {
                fileName: "[project]/src/app/courses/[id]/page.tsx",
                lineNumber: 188,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/courses/[id]/page.tsx",
            lineNumber: 187,
            columnNumber: 7
        }, this);
    }
    const currentLesson = course.lessonsList[currentLessonIndex];
    const handleEditorChange = (value)=>{
        if (value !== undefined) {
            setCode(value);
        }
    };
    const getLanguage = (language)=>{
        switch(language.toLowerCase()){
            case "javascript":
                return "javascript";
            case "typescript":
                return "typescript";
            case "python":
                return "python";
            case "java":
                return "java";
            default:
                return "javascript";
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-[var(--background)] to-[var(--background-darker)]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/courses",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                        whileHover: {
                            x: -5,
                            scale: 1.02
                        },
                        whileTap: {
                            scale: 0.98
                        },
                        className: "flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors mb-8 cursor-pointer group",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                animate: {
                                    x: [
                                        0,
                                        -3,
                                        0
                                    ]
                                },
                                transition: {
                                    repeat: Infinity,
                                    duration: 1.5
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faArrowLeft"]
                                }, void 0, false, {
                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                    lineNumber: 235,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "group-hover:underline",
                                children: "Back to Courses"
                            }, void 0, false, {
                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                lineNumber: 237,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                        lineNumber: 226,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                    lineNumber: 225,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 lg:grid-cols-4 gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    opacity: 0,
                                    x: -20
                                },
                                animate: {
                                    opacity: 1,
                                    x: 0
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: "bg-[var(--background-lighter)]/50 backdrop-blur-sm rounded-xl p-6 sticky top-6 border border-white/5 shadow-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-bold mb-4 text-xl text-gray-200",
                                        children: "Lessons"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                        lineNumber: 249,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2",
                                        children: course.lessonsList.map((lesson, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                whileHover: {
                                                    x: 5,
                                                    scale: 1.02,
                                                    backgroundColor: index === currentLessonIndex ? "rgba(59, 130, 246, 0.8)" : "rgba(31, 41, 55, 0.8)",
                                                    boxShadow: "0 0 20px rgba(59, 130, 246, 0.2)"
                                                },
                                                whileTap: {
                                                    scale: 0.98
                                                },
                                                transition: {
                                                    type: "spring",
                                                    stiffness: 400,
                                                    damping: 17
                                                },
                                                className: `p-3 rounded-lg cursor-pointer transition-all duration-300 relative overflow-hidden ${index === currentLessonIndex ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg" : "bg-[var(--background-darker)]/50 hover:bg-[var(--background-darker)] text-gray-400 hover:text-gray-200"}`,
                                                onClick: ()=>{
                                                    setCurrentLessonIndex(index);
                                                    setCode(lesson.initialCode);
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                        className: "absolute inset-0 bg-gradient-to-r from-blue-500/0 via-blue-500/10 to-blue-500/0",
                                                        initial: {
                                                            x: "-100%"
                                                        },
                                                        whileHover: {
                                                            x: "100%"
                                                        },
                                                        transition: {
                                                            duration: 0.8,
                                                            repeat: Infinity
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 278,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between relative z-10",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-medium",
                                                                children: lesson.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 285,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                whileHover: {
                                                                    rotate: 360
                                                                },
                                                                transition: {
                                                                    duration: 0.5
                                                                },
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                    icon: lesson.completed ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faUnlock"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLock"],
                                                                    className: "text-xs"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                    lineNumber: 290,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 286,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 284,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, lesson.id, true, {
                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                lineNumber: 252,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                        lineNumber: 250,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                lineNumber: 243,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                            lineNumber: 242,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-3",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                initial: {
                                    opacity: 0,
                                    y: 20
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: "bg-[var(--background-lighter)]/50 backdrop-blur-sm rounded-xl p-8 mb-8 border border-white/5 shadow-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-8",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
                                                        initial: {
                                                            opacity: 0,
                                                            y: 20
                                                        },
                                                        animate: {
                                                            opacity: 1,
                                                            y: 0
                                                        },
                                                        className: "text-3xl font-bold mb-3 bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent",
                                                        children: course.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 312,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4 text-sm text-gray-400",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
                                                                whileHover: {
                                                                    scale: 1.05
                                                                },
                                                                className: "px-3 py-1 rounded-full bg-blue-500/10 text-blue-400",
                                                                children: course.level
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 320,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "•"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 326,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: course.duration
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 327,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "•"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 328,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    course.lessons,
                                                                    " lessons"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 329,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 319,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                lineNumber: 311,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
                                                whileHover: {
                                                    scale: 1.05
                                                },
                                                className: "text-sm font-medium px-4 py-2 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg",
                                                children: course.language
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                lineNumber: 332,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                        lineNumber: 310,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-8",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                initial: {
                                                    opacity: 0,
                                                    y: 20
                                                },
                                                animate: {
                                                    opacity: 1,
                                                    y: 0
                                                },
                                                transition: {
                                                    delay: 0.2
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-2xl font-bold mb-3 text-gray-200",
                                                        children: currentLesson.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 346,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-gray-400 mb-4 leading-relaxed",
                                                        children: currentLesson.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 347,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-[var(--background-darker)]/50 rounded-xl p-6 border border-white/5",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "font-bold mb-3 text-gray-200",
                                                                children: "Task:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 349,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-gray-400 leading-relaxed",
                                                                children: currentLesson.task
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 350,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 348,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                lineNumber: 341,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                                                    whileHover: {
                                                                        scale: 1.05,
                                                                        boxShadow: "0 0 20px rgba(59, 130, 246, 0.5)"
                                                                    },
                                                                    whileTap: {
                                                                        scale: 0.95
                                                                    },
                                                                    onClick: runCode,
                                                                    disabled: isRunning,
                                                                    className: "bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-3 rounded-xl flex items-center gap-3 font-medium shadow-lg transition-all duration-300 disabled:opacity-50",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faPlay"]
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                            lineNumber: 364,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: "Run Code"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                            lineNumber: 365,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                    lineNumber: 357,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                                                    whileHover: {
                                                                        scale: 1.05
                                                                    },
                                                                    whileTap: {
                                                                        scale: 0.95
                                                                    },
                                                                    onClick: resetCode,
                                                                    className: "bg-[var(--background-darker)]/50 text-gray-400 hover:text-gray-200 px-8 py-3 rounded-xl flex items-center gap-3 font-medium border border-white/5 transition-all duration-300",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faRedo"]
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                            lineNumber: 373,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: "Reset"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                            lineNumber: 374,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                    lineNumber: 367,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                            lineNumber: 356,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 355,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                        initial: {
                                                            opacity: 0,
                                                            y: 20
                                                        },
                                                        animate: {
                                                            opacity: 1,
                                                            y: 0
                                                        },
                                                        transition: {
                                                            delay: 0.3
                                                        },
                                                        className: "rounded-xl overflow-hidden border border-white/5 shadow-lg",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$monaco$2d$editor$2f$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"], {
                                                            height: "400px",
                                                            defaultLanguage: getLanguage(course.language),
                                                            language: getLanguage(course.language),
                                                            value: code,
                                                            onChange: handleEditorChange,
                                                            theme: "vs-dark",
                                                            options: {
                                                                minimap: {
                                                                    enabled: false
                                                                },
                                                                fontSize: 14,
                                                                lineNumbers: "on",
                                                                roundedSelection: false,
                                                                scrollBeyondLastLine: false,
                                                                automaticLayout: true
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                            lineNumber: 385,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 379,
                                                        columnNumber: 19
                                                    }, this),
                                                    testResults.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                        initial: {
                                                            opacity: 0,
                                                            y: 20
                                                        },
                                                        animate: {
                                                            opacity: 1,
                                                            y: 0
                                                        },
                                                        className: "mt-6 bg-[var(--background-darker)]/50 rounded-xl p-6 border border-white/5",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "font-bold mb-4 text-gray-200",
                                                                children: "Test Results:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 409,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "space-y-3",
                                                                children: currentLesson.testCases.map((test, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                        initial: {
                                                                            opacity: 0,
                                                                            x: -20
                                                                        },
                                                                        animate: {
                                                                            opacity: 1,
                                                                            x: 0
                                                                        },
                                                                        transition: {
                                                                            delay: index * 0.1
                                                                        },
                                                                        className: `p-4 rounded-lg ${testResults[index] ? "bg-green-500/10 border border-green-500/20" : "bg-red-500/10 border border-red-500/20"}`,
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                                    whileHover: {
                                                                                        rotate: 360
                                                                                    },
                                                                                    transition: {
                                                                                        duration: 0.5
                                                                                    },
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                                        icon: testResults[index] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faCheck"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faRedo"],
                                                                                        className: testResults[index] ? "text-green-400" : "text-red-400"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                        lineNumber: 428,
                                                                                        columnNumber: 33
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                    lineNumber: 424,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "flex-1",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                            className: "text-sm font-medium text-gray-200 mb-1",
                                                                                            children: test.description
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                            lineNumber: 434,
                                                                                            columnNumber: 33
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-xs text-gray-400",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                                    children: [
                                                                                                        "Input: ",
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                                                                            className: "bg-[var(--background-darker)] px-2 py-1 rounded",
                                                                                                            children: test.input
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                                            lineNumber: 438,
                                                                                                            columnNumber: 45
                                                                                                        }, this)
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                                    lineNumber: 438,
                                                                                                    columnNumber: 35
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                                    children: [
                                                                                                        "Expected: ",
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                                                                            className: "bg-[var(--background-darker)] px-2 py-1 rounded",
                                                                                                            children: test.expected
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                                            lineNumber: 439,
                                                                                                            columnNumber: 48
                                                                                                        }, this)
                                                                                                    ]
                                                                                                }, void 0, true, {
                                                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                                    lineNumber: 439,
                                                                                                    columnNumber: 35
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                            lineNumber: 437,
                                                                                            columnNumber: 33
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                    lineNumber: 433,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: `text-sm font-medium ${testResults[index] ? "text-green-400" : "text-red-400"}`,
                                                                                    children: testResults[index] ? "Passed" : "Failed"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                                    lineNumber: 442,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                            lineNumber: 423,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, index, false, {
                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                        lineNumber: 412,
                                                                        columnNumber: 27
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 410,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 404,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between mt-8",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                                                whileHover: {
                                                                    scale: 1.05,
                                                                    x: -5
                                                                },
                                                                whileTap: {
                                                                    scale: 0.95
                                                                },
                                                                onClick: previousLesson,
                                                                disabled: currentLessonIndex === 0,
                                                                className: "bg-[var(--background-darker)]/50 text-gray-400 hover:text-gray-200 px-8 py-3 rounded-xl flex items-center gap-3 font-medium border border-white/5 transition-all duration-300 disabled:opacity-50",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faArrowLeft"]
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                        lineNumber: 462,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: "Previous"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                        lineNumber: 463,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 455,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].button, {
                                                                whileHover: {
                                                                    scale: 1.05,
                                                                    x: 5
                                                                },
                                                                whileTap: {
                                                                    scale: 0.95
                                                                },
                                                                onClick: nextLesson,
                                                                disabled: currentLessonIndex === course.lessonsList.length - 1,
                                                                className: "bg-gradient-to-r from-blue-500 to-blue-600 text-white px-8 py-3 rounded-xl flex items-center gap-3 font-medium shadow-lg transition-all duration-300 disabled:opacity-50",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: "Next"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                        lineNumber: 472,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faArrowRight"]
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                        lineNumber: 473,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                                lineNumber: 465,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                        lineNumber: 454,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                                lineNumber: 354,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/courses/[id]/page.tsx",
                                        lineNumber: 340,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/courses/[id]/page.tsx",
                                lineNumber: 304,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/courses/[id]/page.tsx",
                            lineNumber: 303,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/courses/[id]/page.tsx",
                    lineNumber: 241,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/courses/[id]/page.tsx",
            lineNumber: 224,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/courses/[id]/page.tsx",
        lineNumber: 223,
        columnNumber: 5
    }, this);
}
_s(CoursePage, "04uS9P/k4qP7XZgU+WAxq4ihqJI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCourseStore"]
    ];
});
_c2 = CoursePage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "MonacoEditor$dynamic");
__turbopack_context__.k.register(_c1, "MonacoEditor");
__turbopack_context__.k.register(_c2, "CoursePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_c9a1e706._.js.map