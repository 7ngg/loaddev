module.exports = {

"[project]/src/app/courses/template.tsx [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_app_courses_template_tsx_c85edb68._.js.map