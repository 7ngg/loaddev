(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_framer-motion_dist_es_82de910d._.js",
  "static/chunks/node_modules_motion-dom_dist_es_eae4c9f6._.js",
  "static/chunks/node_modules_@fortawesome_free-solid-svg-icons_index_mjs_6d4e8d45._.js",
  "static/chunks/node_modules_motion-utils_dist_es_7559145f._.js",
  "static/chunks/src_app_about_page_tsx_968d425c._.js"
],
    source: "dynamic"
});
