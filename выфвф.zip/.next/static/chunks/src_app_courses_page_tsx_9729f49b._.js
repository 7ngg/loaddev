(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5d544214._.js",
  "static/chunks/src_app_courses_page_tsx_26377da5._.js"
],
    source: "dynamic"
});
