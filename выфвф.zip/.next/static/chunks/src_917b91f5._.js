(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/store/courseStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useCourseStore": (()=>useCourseStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
// Безопасное выполнение JavaScript кода
const safeEval = (code, validationFunction)=>{
    try {
        const fn = new Function(`
      ${code}
      return (${validationFunction})();
    `);
        return fn();
    } catch (error) {
        return false;
    }
};
// Проверка JavaScript кода
const validateJavaScript = (code, testCases)=>{
    return testCases.map((test)=>{
        try {
            const result = safeEval(code, test.validationFunction);
            return String(result) === test.expectedBehavior;
        } catch  {
            return false;
        }
    });
};
// Проверка Python кода (в реальном приложении здесь будет отправка на Python-сервер)
const validatePython = (code, testCases)=>{
    // Здесь будет реальная проверка Python кода
    return testCases.map((test)=>{
        try {
            // В реальном приложении здесь будет отправка кода на Python-сервер
            // и получение результата выполнения
            return false;
        } catch  {
            return false;
        }
    });
};
// Проверка TypeScript кода
const validateTypeScript = (code, testCases)=>{
    // В реальном приложении здесь будет компиляция TypeScript
    return testCases.map((test)=>{
        try {
            const result = safeEval(code, test.validationFunction);
            return String(result) === test.expectedBehavior;
        } catch  {
            return false;
        }
    });
};
// Проверка Java кода
const validateJava = (code, testCases)=>{
    // В реальном приложении здесь будет компиляция и выполнение Java кода
    return testCases.map((test)=>{
        try {
            // В реальном приложении здесь будет отправка кода на Java-сервер
            // и получение результата выполнения
            return false;
        } catch  {
            return false;
        }
    });
};
const useCourseStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        courses: {
            "javascript-basics": {
                id: "javascript-basics",
                title: "JavaScript Fundamentals",
                description: "Master the basics of JavaScript programming",
                level: "Beginner",
                duration: "4 weeks",
                lessons: 24,
                exercises: 12,
                language: "javascript",
                lessonsList: [
                    {
                        id: "calculator",
                        title: "Simple Calculator",
                        description: "Create a calculator that can perform basic arithmetic operations",
                        task: `Create a calculator function that:
1. Takes two numbers and an operation as parameters
2. Supports addition, subtraction, multiplication, and division
3. Returns the result of the operation
4. Handles division by zero
5. Returns null for invalid operations`,
                        initialCode: `function calculator(a, b, operation) {
  // Your code here
  // Example:
  // calculator(5, 3, '+') should return 8
  // calculator(5, 3, '-') should return 2
  // calculator(5, 3, '*') should return 15
  // calculator(6, 3, '/') should return 2
  // calculator(5, 0, '/') should return null
  // calculator(5, 3, 'invalid') should return null
}`,
                        testCases: [
                            {
                                input: "calculator(5, 3, '+')",
                                expectedBehavior: "Should return 8",
                                description: "Addition test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '+');
                return typeof result === 'number' && result === 8;
              }`
                            },
                            {
                                input: "calculator(5, 3, '-')",
                                expectedBehavior: "Should return 2",
                                description: "Subtraction test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '-');
                return typeof result === 'number' && result === 2;
              }`
                            },
                            {
                                input: "calculator(5, 3, '*')",
                                expectedBehavior: "Should return 15",
                                description: "Multiplication test",
                                validationFunction: `() => {
                const result = calculator(5, 3, '*');
                return typeof result === 'number' && result === 15;
              }`
                            },
                            {
                                input: "calculator(6, 3, '/')",
                                expectedBehavior: "Should return 2",
                                description: "Division test",
                                validationFunction: `() => {
                const result = calculator(6, 3, '/');
                return typeof result === 'number' && result === 2;
              }`
                            },
                            {
                                input: "calculator(5, 0, '/')",
                                expectedBehavior: "Should return null for division by zero",
                                description: "Division by zero test",
                                validationFunction: `() => {
                const result = calculator(5, 0, '/');
                return result === null;
              }`
                            },
                            {
                                input: "calculator(5, 3, 'invalid')",
                                expectedBehavior: "Should return null for invalid operation",
                                description: "Invalid operation test",
                                validationFunction: `() => {
                const result = calculator(5, 3, 'invalid');
                return result === null;
              }`
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "array-manipulation",
                        title: "Array Manipulation",
                        description: "Create functions to manipulate arrays",
                        task: `Create a function that:
1. Takes an array of numbers
2. Removes all duplicates
3. Sorts the array in ascending order
4. Returns the sum of all numbers
5. Handles empty arrays and invalid input`,
                        initialCode: `function processArray(arr) {
  // Your code here
  // Example:
  // processArray([1, 2, 2, 3, 3, 4]) should return 10
  // processArray([]) should return 0
  // processArray(null) should return 0
}`,
                        testCases: [
                            {
                                input: "processArray([1, 2, 2, 3, 3, 4])",
                                expectedBehavior: "Should return sum of unique sorted numbers",
                                description: "Basic array processing test",
                                validationFunction: `() => {
                const result = processArray([1, 2, 2, 3, 3, 4]);
                return typeof result === 'number' && result === 10;
              }`
                            },
                            {
                                input: "processArray([])",
                                expectedBehavior: "Should return 0 for empty array",
                                description: "Empty array test",
                                validationFunction: `() => {
                const result = processArray([]);
                return result === 0;
              }`
                            },
                            {
                                input: "processArray(null)",
                                expectedBehavior: "Should return 0 for invalid input",
                                description: "Invalid input test",
                                validationFunction: `() => {
                const result = processArray(null);
                return result === 0;
              }`
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "string-manipulation",
                        title: "String Manipulation",
                        description: "Create functions to manipulate strings",
                        task: `Create a function that:
1. Takes a string as input
2. Reverses the string
3. Removes all spaces
4. Converts to lowercase
5. Returns the result
6. Handles empty strings and invalid input`,
                        initialCode: `function processString(str) {
  // Your code here
  // Example:
  // processString("Hello World") should return "dlrowolleh"
  // processString("") should return ""
  // processString(null) should return ""
}`,
                        testCases: [
                            {
                                input: 'processString("Hello World")',
                                expectedBehavior: "Should return reversed string without spaces",
                                description: "Basic string processing test",
                                validationFunction: `() => {
                const result = processString("Hello World");
                return result === "dlrowolleh";
              }`
                            },
                            {
                                input: 'processString("")',
                                expectedBehavior: "Should return empty string",
                                description: "Empty string test",
                                validationFunction: `() => {
                const result = processString("");
                return result === "";
              }`
                            },
                            {
                                input: "processString(null)",
                                expectedBehavior: "Should return empty string for invalid input",
                                description: "Invalid input test",
                                validationFunction: `() => {
                const result = processString(null);
                return result === "";
              }`
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "python-basics": {
                id: "python-basics",
                title: "Python Programming",
                description: "Learn Python from scratch with practical examples",
                level: "Beginner",
                duration: "6 weeks",
                lessons: 30,
                exercises: 15,
                language: "python",
                lessonsList: [
                    {
                        id: "python-variables",
                        title: "Python Variables and Data Types",
                        description: "Learn about Python variables and basic data types",
                        task: "Create variables of different types and a function that returns their types",
                        initialCode: "# Create variables of different types\nnumber = 42\nstring = 'Hello'\nboolean = True\nmy_list = [1, 2, 3]\nmy_dict = {'name': 'John'}\n\n# Create a function that returns the types of these variables\ndef get_types():\n    # Your code here\n    return [\n        type(number),\n        type(string),\n        type(boolean),\n        type(my_list),\n        type(my_dict)\n    ]\n",
                        testCases: [
                            {
                                input: "str(get_types()[0])",
                                expectedBehavior: "<class 'int'>",
                                description: "Integer type check"
                            },
                            {
                                input: "str(get_types()[1])",
                                expectedBehavior: "<class 'str'>",
                                description: "String type check"
                            },
                            {
                                input: "str(get_types()[2])",
                                expectedBehavior: "<class 'bool'>",
                                description: "Boolean type check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "python-functions",
                        title: "Python Functions",
                        description: "Learn about Python function definitions and scope",
                        task: "Create a function that demonstrates different scopes and returns the correct values",
                        initialCode: "# Create a function that demonstrates different scopes\ndef demonstrate_scope():\n    global_var = 'I am global'\n    \n    def inner():\n        local_var = 'I am local'\n        return [global_var, local_var]\n    \n    # Your code here\n    return inner()\n",
                        testCases: [
                            {
                                input: "demonstrate_scope()[0]",
                                expectedBehavior: "I am global",
                                description: "Global scope access check"
                            },
                            {
                                input: "demonstrate_scope()[1]",
                                expectedBehavior: "I am local",
                                description: "Local scope access check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "python-lists",
                        title: "Python Lists and List Comprehension",
                        description: "Learn about Python list operations and list comprehension",
                        task: "Create a function that uses list comprehension to transform data",
                        initialCode: "# Create a function that uses list comprehension\ndef transform_list(numbers):\n    # Your code here\n    # 1. Filter out even numbers\n    # 2. Square the remaining numbers\n    # 3. Return the sum\n    return sum([x**2 for x in numbers if x % 2 != 0])\n",
                        testCases: [
                            {
                                input: "transform_list([1, 2, 3, 4, 5])",
                                expectedBehavior: "35",
                                description: "List transformation check"
                            },
                            {
                                input: "transform_list([2, 4, 6, 8])",
                                expectedBehavior: "0",
                                description: "Empty result check"
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "typescript-advanced": {
                id: "typescript-advanced",
                title: "TypeScript Mastery",
                description: "Advanced TypeScript patterns and best practices",
                level: "Advanced",
                duration: "8 weeks",
                lessons: 32,
                exercises: 18,
                language: "typescript",
                lessonsList: [
                    {
                        id: "typescript-generics",
                        title: "TypeScript Generics",
                        description: "Learn about TypeScript generics and type constraints",
                        task: "Create a generic function that works with different types",
                        initialCode: "// Create a generic function\nfunction processData<T>(data: T): T {\n  // Your code here\n  return data;\n}\n\n// Create a generic class\nclass Container<T> {\n  private value: T;\n\n  constructor(value: T) {\n    this.value = value;\n  }\n\n  getValue(): T {\n    return this.value;\n  }\n}\n",
                        testCases: [
                            {
                                input: "processData<number>(42)",
                                expectedBehavior: "42",
                                description: "Generic function with number"
                            },
                            {
                                input: "new Container<string>('test').getValue()",
                                expectedBehavior: "test",
                                description: "Generic class with string"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "typescript-interfaces",
                        title: "TypeScript Interfaces",
                        description: "Learn about TypeScript interfaces and type definitions",
                        task: "Create an interface and implement it in a class",
                        initialCode: "// Create an interface\ninterface User {\n  id: number;\n  name: string;\n  email: string;\n}\n\n// Create a class that implements the interface\nclass UserImpl implements User {\n  // Your code here\n  constructor(\n    public id: number,\n    public name: string,\n    public email: string\n  ) {}\n}\n",
                        testCases: [
                            {
                                input: "new UserImpl(1, 'John', 'john@example.com').name",
                                expectedBehavior: "John",
                                description: "Interface implementation check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "typescript-advanced-types",
                        title: "Advanced TypeScript Types",
                        description: "Learn about advanced TypeScript type features",
                        task: "Create utility types and type guards",
                        initialCode: "// Create utility types\ntype Nullable<T> = T | null;\ntype ReadOnly<T> = { readonly [P in keyof T]: T[P] };\n\n// Create a type guard\nfunction isString(value: unknown): value is string {\n  return typeof value === 'string';\n}\n\n// Create a function that uses these types\nfunction processValue<T>(value: Nullable<T>): string {\n  if (value === null) return 'null';\n  if (isString(value)) return value.toUpperCase();\n  return String(value);\n}\n",
                        testCases: [
                            {
                                input: "processValue('hello')",
                                expectedBehavior: "HELLO",
                                description: "Type guard check"
                            },
                            {
                                input: "processValue(null)",
                                expectedBehavior: "null",
                                description: "Nullable type check"
                            }
                        ],
                        completed: false
                    }
                ]
            },
            "java-basics": {
                id: "java-basics",
                title: "Java Programming",
                description: "Learn Java programming fundamentals",
                level: "Intermediate",
                duration: "8 weeks",
                lessons: 36,
                exercises: 20,
                language: "java",
                lessonsList: [
                    {
                        id: "java-classes",
                        title: "Java Classes and Objects",
                        description: "Learn about Java classes and object-oriented programming",
                        task: "Create a class with properties and methods",
                        initialCode: "public class Person {\n    private String name;\n    private int age;\n\n    // Create constructor\n    public Person(String name, int age) {\n        this.name = name;\n        this.age = age;\n    }\n\n    // Create getters and setters\n    public String getName() {\n        return name;\n    }\n\n    public void setName(String name) {\n        this.name = name;\n    }\n\n    public int getAge() {\n        return age;\n    }\n\n    public void setAge(int age) {\n        this.age = age;\n    }\n\n    // Create a method that returns a string representation\n    public String toString() {\n        return name + \" is \" + age + \" years old\";\n    }\n}\n",
                        testCases: [
                            {
                                input: "new Person(\"John\", 25).toString()",
                                expectedBehavior: "John is 25 years old",
                                description: "Class implementation check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "java-interfaces",
                        title: "Java Interfaces",
                        description: "Learn about Java interfaces and their implementation",
                        task: "Create an interface and implement it in a class",
                        initialCode: "interface Drawable {\n    void draw();\n    String getColor();\n}\n\nclass Circle implements Drawable {\n    private String color;\n    private double radius;\n\n    public Circle(String color, double radius) {\n        this.color = color;\n        this.radius = radius;\n    }\n\n    @Override\n    public void draw() {\n        // Implementation would go here\n    }\n\n    @Override\n    public String getColor() {\n        return color;\n    }\n\n    public double getArea() {\n        return Math.PI * radius * radius;\n    }\n}\n",
                        testCases: [
                            {
                                input: "new Circle(\"red\", 5.0).getColor()",
                                expectedBehavior: "red",
                                description: "Interface implementation check"
                            },
                            {
                                input: "String.format(\"%.2f\", new Circle(\"blue\", 3.0).getArea())",
                                expectedBehavior: "28.27",
                                description: "Class method check"
                            }
                        ],
                        completed: false
                    },
                    {
                        id: "java-collections",
                        title: "Java Collections",
                        description: "Learn about Java collections framework",
                        task: "Create a class that uses different collection types",
                        initialCode: "import java.util.*;\n\nclass CollectionManager {\n    private List<String> names;\n    private Set<Integer> numbers;\n    private Map<String, Integer> scores;\n\n    public CollectionManager() {\n        names = new ArrayList<>();\n        numbers = new HashSet<>();\n        scores = new HashMap<>();\n    }\n\n    public void addName(String name) {\n        names.add(name);\n    }\n\n    public void addNumber(int number) {\n        numbers.add(number);\n    }\n\n    public void addScore(String name, int score) {\n        scores.put(name, score);\n    }\n\n    public List<String> getNames() {\n        return names;\n    }\n\n    public Set<Integer> getNumbers() {\n        return numbers;\n    }\n\n    public Map<String, Integer> getScores() {\n        return scores;\n    }\n}\n",
                        testCases: [
                            {
                                input: "new CollectionManager().getNames().size()",
                                expectedBehavior: "0",
                                description: "Empty collection check"
                            }
                        ],
                        completed: false
                    }
                ]
            }
        },
        currentLessonIndex: 0,
        code: "",
        isRunning: false,
        testResults: [],
        setCurrentLessonIndex: (index)=>set({
                currentLessonIndex: index
            }),
        setCode: (code)=>set({
                code
            }),
        setIsRunning: (isRunning)=>set({
                isRunning
            }),
        setTestResults: (results)=>set({
                testResults: results
            }),
        resetCode: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const lesson = courses[courseId].lessonsList[currentLessonIndex];
            set({
                code: lesson.initialCode,
                testResults: []
            });
        },
        runCode: ()=>{
            const { courses, currentLessonIndex, code } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            const lesson = course.lessonsList[currentLessonIndex];
            set({
                isRunning: true
            });
            // Выполняем проверку кода в зависимости от языка
            setTimeout(()=>{
                let results = [];
                switch(course.language.toLowerCase()){
                    case "javascript":
                        results = validateJavaScript(code, lesson.testCases);
                        break;
                    case "python":
                        results = validatePython(code, lesson.testCases);
                        break;
                    case "typescript":
                        results = validateTypeScript(code, lesson.testCases);
                        break;
                    case "java":
                        results = validateJava(code, lesson.testCases);
                        break;
                    default:
                        results = lesson.testCases.map(()=>false);
                }
                set({
                    testResults: results,
                    isRunning: false
                });
                // Если все тесты пройдены, отмечаем урок как завершенный
                if (results.every((result)=>result)) {
                    const updatedCourses = {
                        ...courses
                    };
                    updatedCourses[courseId].lessonsList[currentLessonIndex].completed = true;
                    set({
                        courses: updatedCourses
                    });
                }
            }, 1000);
        },
        nextLesson: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            if (currentLessonIndex < course.lessonsList.length - 1) {
                const nextIndex = currentLessonIndex + 1;
                set({
                    currentLessonIndex: nextIndex,
                    code: course.lessonsList[nextIndex].initialCode,
                    testResults: []
                });
            }
        },
        previousLesson: ()=>{
            const { courses, currentLessonIndex } = get();
            const courseId = Object.keys(courses)[0];
            const course = courses[courseId];
            if (currentLessonIndex > 0) {
                const prevIndex = currentLessonIndex - 1;
                set({
                    currentLessonIndex: prevIndex,
                    code: course.lessonsList[prevIndex].initialCode,
                    testResults: []
                });
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/courses/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CoursesPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/react-fontawesome/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/free-solid-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/courseStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const container = {
    hidden: {
        opacity: 0
    },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1
        }
    }
};
const item = {
    hidden: {
        opacity: 0,
        y: 20
    },
    show: {
        opacity: 1,
        y: 0
    }
};
function CoursesPage() {
    _s();
    const { courses } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCourseStore"])();
    const coursesList = Object.values(courses);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-[var(--background)] to-[var(--background-darker)]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                duration: 0.5
            },
            className: "container mx-auto px-4 py-16",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    initial: {
                        opacity: 0,
                        y: -20
                    },
                    animate: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        type: "spring",
                        stiffness: 100,
                        damping: 20,
                        delay: 0.2
                    },
                    className: "text-center mb-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h1, {
                            initial: {
                                opacity: 0,
                                scale: 0.8
                            },
                            animate: {
                                opacity: 1,
                                scale: 1
                            },
                            transition: {
                                delay: 0.3
                            },
                            className: "text-5xl font-bold mb-6 bg-gradient-to-r from-white via-blue-400 to-blue-600 bg-clip-text text-transparent",
                            children: "Programming Courses"
                        }, void 0, false, {
                            fileName: "[project]/src/app/courses/page.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].p, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                delay: 0.4
                            },
                            className: "text-lg text-gray-400 max-w-2xl mx-auto",
                            children: "Learn programming through interactive exercises and real-world projects. Choose your path and start coding today."
                        }, void 0, false, {
                            fileName: "[project]/src/app/courses/page.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/courses/page.tsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    variants: container,
                    initial: "hidden",
                    animate: "show",
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",
                    children: coursesList.map((course)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            variants: item,
                            whileHover: {
                                scale: 1.03,
                                boxShadow: "0 0 30px rgba(59, 130, 246, 0.2)",
                                transition: {
                                    duration: 0.3
                                }
                            },
                            whileTap: {
                                scale: 0.98
                            },
                            className: "group relative bg-[var(--background-lighter)]/50 backdrop-blur-sm rounded-xl overflow-hidden border border-white/5 hover:border-blue-500/20 transition-all duration-300",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    className: "absolute inset-0 bg-gradient-to-r from-blue-500/0 via-blue-500/5 to-blue-500/0",
                                    initial: {
                                        x: "-100%"
                                    },
                                    whileHover: {
                                        x: "100%"
                                    },
                                    transition: {
                                        duration: 1,
                                        repeat: Infinity
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/courses/page.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/courses/${course.id}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-6 relative z-10",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between mb-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
                                                        whileHover: {
                                                            scale: 1.1
                                                        },
                                                        className: "text-sm font-medium px-3 py-1 rounded-full bg-gradient-to-r from-blue-500/20 to-blue-600/20 text-blue-400",
                                                        children: course.language
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                        lineNumber: 93,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
                                                        whileHover: {
                                                            scale: 1.1
                                                        },
                                                        className: "text-sm px-3 py-1 rounded-full bg-[var(--background-darker)]/50 text-gray-400",
                                                        children: course.level
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                        lineNumber: 99,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/courses/page.tsx",
                                                lineNumber: 92,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h2, {
                                                whileHover: {
                                                    x: 5
                                                },
                                                className: "text-xl font-bold mb-3 text-gray-200",
                                                children: course.title
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/courses/page.tsx",
                                                lineNumber: 107,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-gray-400 text-sm mb-6 leading-relaxed",
                                                children: course.description
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/courses/page.tsx",
                                                lineNumber: 113,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between text-sm",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4 text-gray-400",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                whileHover: {
                                                                    scale: 1.1
                                                                },
                                                                className: "flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faCode"],
                                                                        className: "text-blue-400"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                                        lineNumber: 121,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: [
                                                                            course.lessons,
                                                                            " lessons"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                                        lineNumber: 122,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/courses/page.tsx",
                                                                lineNumber: 117,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                whileHover: {
                                                                    scale: 1.1
                                                                },
                                                                className: "flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faLaptopCode"],
                                                                        className: "text-blue-400"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                                        lineNumber: 128,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: [
                                                                            course.exercises,
                                                                            " exercises"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                                        lineNumber: 129,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/courses/page.tsx",
                                                                lineNumber: 124,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                        lineNumber: 116,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                        whileHover: {
                                                            x: 5
                                                        },
                                                        className: "flex items-center gap-2 text-blue-400 group-hover:text-blue-300 transition-colors",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: "Start"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/page.tsx",
                                                                lineNumber: 136,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                                                animate: {
                                                                    x: [
                                                                        0,
                                                                        5,
                                                                        0
                                                                    ]
                                                                },
                                                                transition: {
                                                                    repeat: Infinity,
                                                                    duration: 1.5
                                                                },
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
                                                                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$free$2d$solid$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faArrowRight"]
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/courses/page.tsx",
                                                                    lineNumber: 141,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/courses/page.tsx",
                                                                lineNumber: 137,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/courses/page.tsx",
                                                        lineNumber: 132,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/courses/page.tsx",
                                                lineNumber: 115,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/courses/page.tsx",
                                        lineNumber: 91,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/courses/page.tsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, course.id, true, {
                            fileName: "[project]/src/app/courses/page.tsx",
                            lineNumber: 73,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/courses/page.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/courses/page.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/courses/page.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_s(CoursesPage, "Q7ObijAvKchY0ACoWNDKs6ZSHF0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$courseStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCourseStore"]
    ];
});
_c = CoursesPage;
var _c;
__turbopack_context__.k.register(_c, "CoursesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_917b91f5._.js.map